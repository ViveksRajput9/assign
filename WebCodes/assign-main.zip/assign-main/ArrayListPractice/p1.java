package ArrayListPractice;

import java.util.ArrayList;

public class p1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList ar = new ArrayList();
		ar.add(10);
		ar.add(150);
		ar.add("vivek");
		ar.add(10);
		ar.add(3,"vivek");
		System.out.println(ar);

	}
}