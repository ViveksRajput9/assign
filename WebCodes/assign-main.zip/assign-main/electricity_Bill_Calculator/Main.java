package electricity_Bill_Calculator;
public class Main implements DomesticBill{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		calculateBill(25,"Rural");
	}

}
 